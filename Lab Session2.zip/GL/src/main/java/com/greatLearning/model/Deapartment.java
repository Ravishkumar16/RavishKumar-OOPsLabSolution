package com.greatLearning.model;

public class Deapartment {
	String departName = null;

	public  String Deapartmentname(int x) {

		switch (x) {
		case 1:
			departName = "Technical";
			break;
		case 2:
			departName = "Admin";
			break;
		case 3:
			departName = "Human Resource";
			break;
		case 4:
			departName = "Legal";
			break;
		default:
			System.out.println("Wrong input");

		}
		
		return departName;

	}

}
