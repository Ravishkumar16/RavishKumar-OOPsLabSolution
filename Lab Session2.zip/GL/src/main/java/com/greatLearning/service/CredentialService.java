package com.greatLearning.service;

import java.util.Random;

import com.greatLearning.model.Employee;

public class CredentialService {
	String generatedemailAddress="";
	String numbers = "1234567890";
	String generatedpassword ="";
	String capitalLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	String smallLetters = "abcdefghijklmnopqrstuvwxyz";
	String specialChars = "!@#$%^&*()";

	public String generatePassword(){
		Random randomize = new Random();
		char [] password = new char[2];
		char [] password1 = new char[2];
		char [] password2= new char[2];
		char [] password3= new char[2];

		
		for (int i = 0; i < 2; i++) {
	
				password[i] = numbers.charAt(randomize.nextInt(numbers.length()));
				password1[i] = smallLetters.charAt(randomize.nextInt(smallLetters.length()));
				password2[i] = capitalLetters.charAt(randomize.nextInt(capitalLetters.length()));
				password3[i] = specialChars.charAt(randomize.nextInt(specialChars.length()));
			
			}
		
		generatedpassword =	String.valueOf(password)+String.valueOf(password1)+String.valueOf(password2)+String.valueOf(password3);
		return generatedpassword;
	}
	public String generateEmailAddress(String firstName, String LastlastName, String DeptName){
		
		generatedemailAddress = firstName+LastlastName+"@"+DeptName+".company.com";
		return generatedemailAddress;
	
	}
	
	
	public void showPassword(Employee empObject, String email, String generatedPassword){
		
		System.out.println("Dear "+empObject.getFirstName() +" Your generated credetials are as follows :");
		System.out.println("Email  ------> "+ email);
		System.out.println("Password  ------> "+ generatedPassword);
		
	}
	
	
}
